export interface Supermercado {
    nombre: string,
    horario: string[],
    whatsApp: number,
    ubicacion: string
}
