export interface Cliente {
    nombre: string,
    correoElectronico: string,
    supermercadoAsociado: string,
    mensaje: string
}
